# Help documents
This section of the website will contain help documents for workspace UX. The help articles will be updated as more features are added to workspace. The current help features are for Workspace Build 7121Rm

**Topics in help section**

- [Setup workspace](setup.md)